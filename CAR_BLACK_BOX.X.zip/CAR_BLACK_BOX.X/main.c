/*
 * File:   main.c
 * Author: nakul
 *
 * Created on 9 April, 2026, 10:32 PM
 */


#include <xc.h>
#include "clcd.h"
#include "black_box.h"
#include "matrix_keypad.h"
#include "adc.h"
#include "ds1307.h"
#include "i2c.h"
#include "uart.h"

unsigned char prev_state = 0;
unsigned char key;

State_t state;

void init_config()
{
    state = e_dashboard;
        init_clcd();       

         init_adc();        

    init_matrix_keypad();
    init_i2c();
    // Initialize ADC module for reading speed

    // Initialize Character LCD for display
        init_ds1307();
        init_uart();

    
}

void main(void) 
{
    init_config();
    
    while(1)
    {
        // Detect key press
        key  = read_switch(STATE_CHANGE);
        
        if(prev_state != state){
            CLEAR_DISP_SCREEN;
        }
        switch (state)
        {
            case e_dashboard:
                // Display dashboard 
                view_dashboard();
                
                break;
            
            case e_main_menu:
                // Display dashboard
                display_main_menu();
                break;
            
            case e_view_log:
                // Display dashboard
                view_log();
                break;
                 
            case e_download_log:
                download_log();
                break;
                
            case e_clear_log:
                clear_log();
                break;
                
                      
            case e_set_time:
                set_time();
                break;
                
                
        }
        prev_state = state;
    }
    
}
