#ifndef MATRIX_KEYPAD_H
#define MATRIX_KEYPAD_H

#define LEVEL					     	0
#define STATE_CHANGE			       	1

#define KEY_PORT					PORTC

#define SWITCH1					0x0E
#define SWITCH2					0x0D
#define SWITCH3					0x0B
#define SWITCH4					0x07
#define ALL_RELEASED					0x0F

#define INPUT_PINS					0x0F


#define MK_SW1					1
#define MK_SW2					2
#define MK_SW3					3
#define MK_SW4					4
#define MK_SW5					5
#define MK_SW6					6
#define MK_SW7					7
#define MK_SW8					8
#define MK_SW9					9
#define MK_SW10				10
#define MK_SW11				11
#define MK_SW12				12

#define ALL_RELEASED	0xFF

#define ROW1    PORTBbits.RB5
#define ROW2    PORTBbits.RB6
#define ROW3    PORTBbits.RB7

#define COL1    PORTBbits.RB1
#define COL2    PORTBbits.RB2
#define COL3    PORTBbits.RB3
#define COL4    PORTBbits.RB4



int switch_scan(void);
int read_switch(char type);
void init_matrix_keypad(void);

#endif