/*
 * File:   matrix_keypad.c
 * Author: nakul
 *
 * Created on 9 April, 2026, 10:50 PM
 */


#include <xc.h>
#include "matrix_keypad.h"

#define _XTAL_FREQ 20000000

void init_matrix_keypad(void)
{
	/* Config PORTB as digital */
	ADCON1 = 0x0F;

	/* Set Rows (RB7 - RB5) as Outputs and Columns (RB4 - RB1) as Inputs */
	TRISB = 0x1E;

	/* Set PORTB input as pull up for columns */
	RBPU = 0; 
}



int switch_scan(void)
{
   // ROW1 active
    ROW1 = 0; ROW2 = 1; ROW3 = 1;
    __delay_us(50);

    if(COL1 == 0) return 1;
    if(COL2 == 0) return 4;
    if(COL3 == 0) return 7;
    if(COL4 == 0) return 10;

    // ROW2 active
    ROW1 = 1; ROW2 = 0; ROW3 = 1;
    __delay_us(50);

    if(COL1 == 0) return 2;
    if(COL2 == 0) return 5;
    if(COL3 == 0) return 8;
    if(COL4 == 0) return 11;

    // ROW3 active
    ROW1 = 1; ROW2 = 1; ROW3 = 0;
    __delay_us(50);

    if(COL1 == 0) return 3;
    if(COL2 == 0) return 6;
    if(COL3 == 0) return 9;
    if(COL4 == 0) return 12;

    return 0; 
}

int read_switch(char type)
{
    static unsigned char once = 1;
    int key = switch_scan();

    if(type == LEVEL)
    {
        return switch_scan();
    }
    else if(type == STATE_CHANGE)
    {
        if(key != 0 && once)
        {
            __delay_ms(20);
            once = 0;
            return switch_scan();
        }
        else if(key == 0)
        {
            once = 1;
        }
    }

    return 0;
}

