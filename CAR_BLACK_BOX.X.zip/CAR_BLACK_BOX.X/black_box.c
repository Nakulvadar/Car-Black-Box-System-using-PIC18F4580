/*
 * File:   black_box.c
 * Author: nakul
 *
 * Created on 9 April, 2026, 10:37 PM
 */


#include <xc.h>
#include "clcd.h"
#include "black_box.h"
#include "matrix_keypad.h"
#include "adc.h"
#include "ds1307.h"
#include "i2c.h"
#include "eeprom.h"
#include<string.h>
#include "uart.h"

#define _XTAL_FREQ 20000000     // System clock frequency (20 MHz)
#define BLINK_ON  500           // Counter threshold to start blinking selected field
#define BLINK_OFF 1000          // Counter threshold to reset blinking cycle

/* ----------- TIME EDIT VARIABLES ----------- */
static signed char hr, min, sec;  
// Editable time values (hours, minutes, seconds)
// signed is used to handle underflow (e.g., 0 ? -1 ? wrap to 23)

/* ----------- EXTERNAL INPUT / STATE ----------- */
extern unsigned char key;      
// Stores keypad input (which switch is pressed)

extern State_t state;          
// Current system state (dashboard, menu, set_time, etc.)

/* ----------- RTC VARIABLES ----------- */
unsigned char clock_reg[3];    
// Raw BCD values read from DS1307 (hour, minute, second registers)

unsigned char time[9];         
// Formatted time string "HH:MM:SS" for LCD display

/* ----------- EEPROM LOGGING ----------- */
unsigned char addr = 0;        
// EEPROM memory address pointer (for storing logs sequentially)

unsigned char event_count;     
// Number of stored events (maximum 10)

unsigned char first_index;     
// Reserved variable (can be used for circular buffer start index)

unsigned char read_data[10][15];  
// Buffer to store 10 log entries (each entry up to 15 characters)

/* ----------- SPEED VARIABLES ----------- */
unsigned char speed;           
// Speed value calculated from ADC input

unsigned char speed_str[4];    
// ASCII representation of speed (2 digits + null terminator)

/* ----------- GEAR SYSTEM ----------- */
unsigned char index = 0;       
// Current gear index used to access gear_str array

char gear_str[9][3] = {
    "ON", "GN", "G1", "G2", "G3", "G4", "G5", "RE", "CO"
};
// Gear labels corresponding to different gear positions

/* ----------- MENU SYSTEM ----------- */
unsigned char scroll = 0;      
// Scroll control variable (currently not heavily used)

unsigned char cursor = 0;      
// Current menu cursor position (range: 0 to 3)

unsigned char menu[4][25] = {
    "View Log",
    "Clear Log",
    "Download Log",
    "Set Time"
};
// Menu options displayed on LCD

/* ----------- GENERAL FLAGS ----------- */
int flag = 0;                  
// General-purpose flag (used based on application logic)

/* ----------- TIME SETTING ----------- */
unsigned char change_time[9];  
// Editable time string used during time-setting mode

static unsigned char set_time_flag = 1;  
// Ensures time values are initialized only once when entering set_time()

/* ----------- LOG VIEW ----------- */
int view_index = 0;            
// Current index for viewing stored logs

static unsigned char view_flag = 1;  
// Flag to initialize log display header only once

/* ----------- DISPLAY TIMING ----------- */
unsigned int delay = 0;



/* ================= FUNCTION DEFINITIONS ================= */

// Read time from DS1307 (BCD format) and convert to "HH:MM:SS" ASCII string

void get_time(void) {
    clock_reg[0] = read_ds1307(HOUR_ADDR);
    clock_reg[1] = read_ds1307(MIN_ADDR);
    clock_reg[2] = read_ds1307(SEC_ADDR);

    if (clock_reg[0] & 0x40) {
        time[0] = '0' + ((clock_reg[0] >> 4) & 0x01);
        time[1] = '0' + (clock_reg[0] & 0x0F);
    } else {
        time[0] = '0' + ((clock_reg[0] >> 4) & 0x03);
        time[1] = '0' + (clock_reg[0] & 0x0F);
    }
    time[2] = ':';
    time[3] = '0' + ((clock_reg[1] >> 4) & 0x0F);
    time[4] = '0' + (clock_reg[1] & 0x0F);
    time[5] = ':';
    time[6] = '0' + ((clock_reg[2] >> 4) & 0x0F);
    time[7] = '0' + (clock_reg[2] & 0x0F);
    time[8] = '\0';
}

// Update gear position based on keypad input and store event on change.
void get_gear_pos() { 
    
    static unsigned short prev_index = 0;

    if (key == 1) {

        if (index < 7)
            index++;
    } else if (key == 2) {
        if (index > 1)
            index--;
    } else if (key == 3) {
        index = 8;
    }
    if (prev_index != index) {
        event_store();
        prev_index = index;
    }

}

// Read ADC value, convert to speed, and store as ASCII string
unsigned char get_speed() {
    // Implement the speed function

    speed = ((read_adc(CHANNEL4)) / 10.33);
    speed_str[0] = (speed / 10) + '0';
    speed_str[1] = (speed % 10) + '0';
    speed_str[2] = '\0';
}

// Store current time, gear, and speed into EEPROM as an event log
void event_store() {

    if (event_count < 10) {
        event_count++;
    }



    for (int i = 0; i < 8; i++)
        write_internal_eeprom(addr++, time[i]);

    write_internal_eeprom(addr++, gear_str[index][0]);
    write_internal_eeprom(addr++, gear_str[index][1]);
    write_internal_eeprom(addr++, (speed / 10) + 48);
    write_internal_eeprom(addr++, (speed % 10) + 48);

    if (addr >= 120) {
        addr = 0;
    }

}

// Display main menu and handle navigation and selection.
void display_main_menu(void) {

    if (key == MK_SW2) // DOWN
    {
        CLEAR_DISP_SCREEN;
        if (cursor < 3)
            cursor++;

    } else if (key == MK_SW1) // UP
    {
        CLEAR_DISP_SCREEN;
        if (cursor > 0)
            cursor--;

    }

    if (cursor == 0) {
        clcd_print("*", LINE1(0));
        clcd_print(menu[cursor], LINE1(2));
        clcd_print(" ", LINE2(0));
        clcd_print(menu[cursor + 1], LINE2(2));
    } else {
        clcd_print(" ", LINE1(0));
        clcd_print(menu[cursor - 1], LINE1(2));
        clcd_print("*", LINE2(0));
        clcd_print(menu[cursor], LINE2(2));
    }

    if (key == MK_SW11) {
        CLEAR_DISP_SCREEN;
        if (cursor == 0) {
            state = e_view_log;
        } else if (cursor == 1) {
            state = e_clear_log;
        } else if (cursor == 2) {
            state = e_download_log;
        } else if (cursor == 3) {
            state = e_set_time;
        }
    } else if (key == MK_SW12) {
        CLEAR_DISP_SCREEN;
        state = e_dashboard;
        cursor = 0;
    }
}

// View stored logs with navigation through events
void view_log(void) {
    if (event_count == 0) {

        CLEAR_DISP_SCREEN;
        clcd_print("No Logs", LINE1(4));
        clcd_print("To View", LINE2(4));
        __delay_ms(1500);
        CLEAR_DISP_SCREEN;
        state = e_main_menu;
        return;
    } else if (key == MK_SW12) {
        view_index = 0;
        view_flag = 1;
        state = e_main_menu;
        CLEAR_DISP_SCREEN;
        return;
    } else if (key == MK_SW2) {
        if (view_index < event_count - 1) {
            view_index++;
        }
    } else if (key == MK_SW1) {
        if (view_index > 0) {
            view_index--;
        }
    }
    if (view_flag) {
        event_reader();
        CLEAR_DISP_SCREEN;
        clcd_print("Time ", LINE1(2));
        clcd_print("EV ", LINE1(9));
        clcd_print("SP", LINE1(12));
        view_flag = 0;
        view_index = 0;
    }
    if (view_index < event_count)
        clcd_print(read_data[view_index], LINE2(0));

}

// Send stored logs via UART and display status
void download_log(void) {
    event_reader();

    if (event_count == 0) {
        CLEAR_DISP_SCREEN;
        clcd_print("No Logs", LINE1(4));
        clcd_print("To Download", LINE2(2));
        __delay_ms(1500);
        CLEAR_DISP_SCREEN;

        state = e_main_menu;
        return;
    }

    for (int i = 0; i < event_count; i++) {
        puts(read_data[i]);
        puts("\n\r");
    }

    CLEAR_DISP_SCREEN;
    clcd_print("Logs Downloaded", LINE1(2));
    clcd_print("Successfully", LINE2(3));
    __delay_ms(1500);
    CLEAR_DISP_SCREEN;
    state = e_main_menu;
}

// Clear all stored logs from EEPROM and reset counters
void clear_log(void) {
    addr = 0;
    event_count = 0;
    view_flag = 1;
    view_index = 0;
    clcd_print("All Logs Cleared", LINE1(0));
    clcd_print("Successfully", LINE2(2));
    __delay_ms(1500);
    CLEAR_DISP_SCREEN;
    state = e_main_menu;
}

// Read stored events from EEPROM and format into readable data
void event_reader(void) {

    unsigned char temp_add = addr;
    if (temp_add != 0 && event_count != 10) {
        temp_add = 0;
    }
    for (int i = 0; i < event_count; i++) {

        for (int j = 0; j < 15; j++) {
            if (j == 8 || j == 11) {
                read_data[i][j] = ' ';
            } else if (j == 14) {
                read_data[i][j] = '\0';
            } else {
                read_data[i][j] = read_internal_eeprom(temp_add);
                temp_add++;
                if (temp_add >= 120) {
                    temp_add = 0;
                }
            }
        }
    }

}

// Convert edited ASCII time to BCD format and write to RTC
void final_time(void) {
    unsigned int finaltime[3];

    finaltime[0] = change_time[7] - 48; // store hour 
    finaltime[0] |= ((change_time[6] - 48) << 4);

    finaltime[1] = change_time[4] - 48; //store min
    finaltime[1] |= ((change_time[3] - 48) << 4);

    finaltime[2] = change_time[1] - 48; // store sec
    finaltime[2] |= ((change_time[0] - 48) << 4);


    for (int i = 0; i < 3; i++)
        write_ds1307(i, finaltime[i]);

}

// Handle time editing UI with cursor movement and blinking effect
void set_time(void) {
    static unsigned int cur = 1;

    if (set_time_flag) {
        hr = ((time[0] - '0') * 10) + (time[1] - '0');
        min = ((time[3] - '0') * 10) + (time[4] - '0');
        sec = ((time[6] - '0') * 10) + (time[7] - '0');
        set_time_flag = 0;
    }

    /* ----------- SWITCH HANDLING ----------- */

    if (key == MK_SW1) {
        if (cur == 1)
            hr++;
        else if (cur == 2)
            min++;
        else if (cur == 3)
            sec++;
    } else if (key == MK_SW2) {
        if (cur == 1)
            hr--;
        else if (cur == 2)
            min--;
        else if (cur == 3)
            sec--;
    }
    else if (key == MK_SW3) // Cursor move
    {
        cur++;
        if (cur > 3)
            cur = 1;
    }
    else if (key == MK_SW11) // Save
    {

        CLEAR_DISP_SCREEN;
        clcd_print("Time Changed", LINE1(2));
        clcd_print("Successfully", LINE2(2));

        __delay_ms(1000);
        final_time();
        cursor = 0;
        state = e_main_menu;
        CLEAR_DISP_SCREEN;
        set_time_flag = 1;
        return;
    } else if (key == MK_SW12) // Cancel
    {
        CLEAR_DISP_SCREEN;
        state = e_main_menu;
        set_time_flag = 1;
        return;
    }

    if (hr < 0) {
        hr = 23;
    }
    if (hr > 23) {
        hr = 0;
    }

    if (min < 0) {
        min = 59;
    }
    if (min > 59) {
        min = 0;
    }

    if (sec < 0) {
        sec = 59;
    }
    if (sec > 59) {
        sec = 0;
    }
    /* ----------- INTEGER ASCII ----------- */


    change_time[0] = (hr / 10) + '0';
    change_time[1] = (hr % 10) + '0';
    change_time[2] = ':';
    change_time[3] = (min / 10) + '0';
    change_time[4] = (min % 10) + '0';
    change_time[5] = ':';
    change_time[6] = (sec / 10) + '0';
    change_time[7] = (sec % 10) + '0';
    change_time[8] = '\0';


    if (delay >= BLINK_ON) {
        if (cur == 1) {
            change_time[0] = ' ';
            change_time[1] = ' ';
        } else if (cur == 2) {
            change_time[3] = ' ';
            change_time[4] = ' ';
        } else if (cur == 3) {
            change_time[6] = ' ';
            change_time[7] = ' ';
        }
    }
    delay++;

    if (delay >= BLINK_OFF) {
        delay = 0;
    }


    /* ----------- DISPLAY ----------- */

    clcd_print("Set Time", LINE1(2));
    clcd_print(change_time, LINE2(2));

}

// Display dashboard with time, gear position, and speed
void view_dashboard(void) {

    speed = get_speed();

    get_gear_pos();

    get_time();

    clcd_print("Time ", LINE1(2));
    clcd_print("EV ", LINE1(9));
    clcd_print("SP", LINE1(13));

    clcd_print(time, LINE2(0));
    clcd_print(gear_str[index], LINE2(9));
    clcd_print(speed_str, LINE2(13));


    if (key == MK_SW11) {
        CLEAR_DISP_SCREEN;
        state = e_main_menu;
    }

}